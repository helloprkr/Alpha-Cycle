# Research Verifier

Automate research verification loops between Claude and Alpharxiv.

## Overview

Research Verifier orchestrates systematic theory validation by:

1. **Generating targeted questions** based on your hypothesis and gaps
2. **Querying Alpharxiv** to find relevant papers and insights
3. **Extracting and organizing** responses, papers, and citations
4. **Tracking gaps** that need investigation
5. **Versioning hypotheses** as evidence accumulates

## Installation

```bash
# Clone or copy the research-verifier directory
cd research-verifier

# Install in development mode
pip install -e .

# Install Playwright browsers
playwright install chromium
```

## Quick Start

```bash
# 1. Create a new research project
rv new my-theory

# 2. Login to Alpharxiv (one-time, saves session)
rv login

# 3. Edit your concept and hypothesis
cd my-theory
# Edit concept/README.md with your theory
# Edit hypotheses/v1/hypothesis.md with your hypothesis

# 4. Run verification cycles
rv run --cycles 2

# 5. Check status anytime
rv status
```

## Commands

| Command | Description |
|---------|-------------|
| `rv new <name>` | Create a new research project |
| `rv login` | Authenticate with Alpharxiv (opens browser) |
| `rv ask "<question>"` | Send a single question to Alpharxiv |
| `rv run --cycles N` | Run N verification cycles |
| `rv run --phase expansive` | Force a specific phase |
| `rv status` | Show current project status |
| `rv resume` | Resume from last checkpoint |

## Project Structure

```
my-theory/
├── config.yaml              # Project settings
├── concept/
│   └── README.md            # Your core theory
├── hypotheses/
│   └── v1/
│       ├── hypothesis.md    # Falsifiable hypothesis
│       ├── components.yaml  # Decomposed claims
│       └── status.yaml      # Validation status
├── research/
│   └── cycle-001/
│       ├── questions.md     # Questions asked
│       ├── responses/       # Individual responses
│       ├── synthesis.md     # Cycle synthesis
│       └── metadata.json    # Cycle statistics
├── gaps/
│   ├── active.yaml          # Open research gaps
│   └── resolved.yaml        # Closed gaps
├── resources/
│   ├── papers.yaml          # Collected papers
│   └── code.yaml            # Related code repos
├── tests/
│   └── registry.yaml        # Validation tests
└── results/                 # Test results
```

## Phases

Research cycles rotate through three phases:

- **Expansive**: Divergent exploration - cast a wide net
- **Integrative**: Convergent synthesis - find connections
- **Synthesis**: Reflective assessment - clarify state

## Usage with Claude Code

This tool is designed to be orchestrated by Claude Code:

1. **You** describe what you want to verify
2. **Claude Code** generates targeted questions
3. **rv** automates the Alpharxiv queries
4. **Claude Code** synthesizes the results
5. **Repeat** for multiple cycles

## Configuration

Edit `config.yaml` in your project:

```yaml
settings:
  cycles_per_run: 20
  checkpoint_interval: 5
  alpharxiv_timeout: 120  # seconds
```

## Troubleshooting

**"Not logged in" errors**: Run `rv login` and complete Google OAuth

**Timeout errors**: Increase `alpharxiv_timeout` in config.yaml

**Session expired**: Run `rv login` again to refresh

**Cycle interrupted**: Use `rv resume` to continue from checkpoint

## License

MIT
