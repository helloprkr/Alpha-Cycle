"""
Alpharxiv browser automation client using Playwright.

Handles:
- Persistent browser session (Google OAuth)
- Sending queries to the assistant
- Extracting responses and paper links
- Session management (new conversations per phase)
"""

import asyncio
import json
import re
from pathlib import Path
from datetime import datetime
from typing import Optional
from dataclasses import dataclass, field

try:
    from playwright.async_api import async_playwright, Browser, Page, BrowserContext
except ImportError:
    print("Playwright not installed. Run: pip install playwright && playwright install chromium")
    raise


@dataclass
class AlpharxivResponse:
    """Structured response from Alpharxiv."""
    text: str
    papers: list = field(default_factory=list)
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    raw_html: str = ""


class AlpharxivClient:
    """Browser automation client for Alpharxiv assistant."""
    
    ALPHARXIV_URL = "https://www.alphaxiv.org/assistant"
    PROFILE_DIR = Path.home() / ".research-verifier" / "browser-profile"
    
    # Selectors (update if DOM changes)
    SELECTORS = {
        "input_box": 'textarea[placeholder*="Ask anything about research"]',
        "send_button": 'button[type="submit"], button:has(svg)',  # The arrow/send button
        "response_container": "div.prose, div[class*='message']",
        "completion_indicator": "button:has-text('Copy'), [aria-label*='Copy']",
        "paper_link": "a[href*='arxiv.org']",
        "paper_pill": "button:has-text('...'), span[class*='truncate']",
    }
    
    def __init__(self, headless: bool = False):
        """
        Initialize client.
        
        Args:
            headless: Run browser in headless mode (False recommended for first login)
        """
        self.headless = headless
        self.browser: Optional[Browser] = None
        self.context: Optional[BrowserContext] = None
        self.page: Optional[Page] = None
        self._playwright = None
        
        # Ensure profile directory exists
        self.PROFILE_DIR.mkdir(parents=True, exist_ok=True)
    
    async def _ensure_browser(self):
        """Ensure browser is running with persistent context."""
        if self.context is not None:
            return
        
        self._playwright = await async_playwright().start()
        
        # Use persistent context to maintain Google login
        self.context = await self._playwright.chromium.launch_persistent_context(
            user_data_dir=str(self.PROFILE_DIR),
            headless=self.headless,
            viewport={"width": 1280, "height": 900},
            args=[
                "--disable-blink-features=AutomationControlled",
                "--no-sandbox",
            ]
        )
        
        # Get or create page
        if self.context.pages:
            self.page = self.context.pages[0]
        else:
            self.page = await self.context.new_page()
    
    async def login_interactive(self):
        """
        Open browser for manual login.
        User logs into Google, then we save the session.
        """
        await self._ensure_browser()
        
        print("Opening Alpharxiv in browser...")
        print("Please log in with your Google account.")
        print("Press Enter in this terminal when you're logged in and see the assistant.")
        
        await self.page.goto(self.ALPHARXIV_URL)
        
        # Wait for user to complete login
        input("\n→ Press Enter after logging in... ")
        
        # Verify we're logged in by checking for the input box
        try:
            await self.page.wait_for_selector(
                self.SELECTORS["input_box"], 
                timeout=5000
            )
            print("✓ Login verified. Session saved.")
        except Exception:
            print("⚠ Could not verify login. You may need to try again.")
        
        await self.close()
    
    async def new_conversation(self):
        """Start a fresh conversation by navigating to the assistant URL."""
        await self._ensure_browser()
        await self.page.goto(self.ALPHARXIV_URL)
        await self.page.wait_for_selector(self.SELECTORS["input_box"], timeout=30000)
        # Small delay to ensure page is fully loaded
        await asyncio.sleep(1)
    
    async def query(self, question: str, timeout_seconds: int = 120) -> AlpharxivResponse:
        """
        Send a question and wait for response.
        
        Args:
            question: The question to ask
            timeout_seconds: Max wait time for response (default 120s for long queries)
            
        Returns:
            AlpharxivResponse with text and extracted papers
        """
        await self._ensure_browser()
        
        # Ensure we're on the right page
        if "alphaxiv.org" not in self.page.url:
            await self.new_conversation()
        
        # Find and fill input
        input_box = await self.page.wait_for_selector(
            self.SELECTORS["input_box"],
            timeout=10000
        )
        
        await input_box.fill(question)
        await asyncio.sleep(0.3)  # Small delay before sending
        
        # Find send button and click
        # The send button appears when there's text in the input
        send_button = await self.page.wait_for_selector(
            'button[type="submit"]:not([disabled]), button:has(svg[class*="arrow"]):not([disabled])',
            timeout=5000
        )
        await send_button.click()
        
        # Wait for response to complete
        # Signal: Copy button appears (thumbs up/down/copy)
        print(f"  ⏳ Waiting for response (timeout: {timeout_seconds}s)...")
        
        # Wait for new content to appear, then wait for completion indicator
        await asyncio.sleep(2)  # Initial delay for response to start
        
        try:
            # Wait for the completion indicator (Copy button)
            await self.page.wait_for_selector(
                self.SELECTORS["completion_indicator"],
                timeout=timeout_seconds * 1000,
                state="visible"
            )
        except Exception as e:
            print(f"  ⚠ Timeout waiting for response completion: {e}")
        
        # Extract response
        return await self._extract_response()
    
    async def _extract_response(self) -> AlpharxivResponse:
        """Extract the latest response text and paper links."""
        
        # Get all message containers - last one should be the response
        messages = await self.page.query_selector_all("div.prose, div[class*='assistant']")
        
        if not messages:
            return AlpharxivResponse(text="[No response found]", papers=[])
        
        # Get the last message (most recent response)
        last_message = messages[-1]
        
        # Extract text content
        text = await last_message.inner_text()
        
        # Extract paper links
        papers = []
        links = await last_message.query_selector_all("a[href*='arxiv.org']")
        
        for link in links:
            href = await link.get_attribute("href")
            title = await link.inner_text()
            
            # Extract arxiv ID from URL
            arxiv_match = re.search(r'arxiv\.org/abs/(\d+\.\d+)', href or "")
            arxiv_id = arxiv_match.group(1) if arxiv_match else None
            
            papers.append({
                "title": title.strip(),
                "url": href,
                "arxiv_id": arxiv_id,
            })
        
        # Also look for paper pills/buttons (truncated titles)
        pills = await last_message.query_selector_all("button, span[class*='truncate']")
        for pill in pills:
            pill_text = await pill.inner_text()
            # These are usually truncated paper titles
            if "..." in pill_text and len(pill_text) > 10:
                # Try to find the full title nearby
                pass  # We'll rely on the arxiv links for now
        
        # Get raw HTML for debugging/archival
        raw_html = await last_message.inner_html()
        
        return AlpharxivResponse(
            text=text,
            papers=papers,
            raw_html=raw_html
        )
    
    async def send_context_recap(self, recap: str):
        """
        Send a context recap at the start of a new conversation.
        Used when starting fresh per Option C (new conversation per phase).
        """
        context_prompt = f"""Context from previous research session:

{recap}

I'm continuing my research from where we left off. Please keep this context in mind for my questions."""
        
        return await self.query(context_prompt)
    
    async def close(self):
        """Close browser gracefully."""
        if self.context:
            await self.context.close()
            self.context = None
            self.page = None
        
        if self._playwright:
            await self._playwright.stop()
            self._playwright = None


# Standalone test
async def test_client():
    """Quick test of the client."""
    client = AlpharxivClient(headless=False)
    
    try:
        # First time: login
        # await client.login_interactive()
        
        # After login: test query
        await client.new_conversation()
        response = await client.query("What are the latest papers on transformer architecture improvements?")
        
        print("\n=== Response ===")
        print(response.text[:500])
        print(f"\n=== Papers ({len(response.papers)}) ===")
        for p in response.papers[:3]:
            print(f"  • {p['title']}: {p['url']}")
            
    finally:
        await client.close()


if __name__ == "__main__":
    asyncio.run(test_client())
